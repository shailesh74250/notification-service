const Bull = require('bull');
const logger = require('../utils/logger');

const emailQueue = new Bull('email queue', {
  redis: process.env.REDIS_URL || 'redis://localhost:6379',
  defaultJobOptions: {
    attempts: 3,
    backoff: {
      type: 'exponential',
      delay: 2000
    },
    removeOnComplete: 100,
    removeOnFail: 50
  }
});

// Only monitoring events, NO processing
emailQueue.on('completed', (job) => {
  logger.info(`Job ${job.id} completed successfully`);
});

emailQueue.on('failed', (job, err) => {
  logger.error(`Job ${job.id} failed`, { error: err.message });
});

emailQueue.on('stalled', (job) => {
  logger.warn(`Job ${job.id} stalled`);
});

module.exports = emailQueue;
