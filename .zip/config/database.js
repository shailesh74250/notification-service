const redis = require('redis');
const { Pool } = require('pg');
require('dotenv').config();

// Redis client
const redisClient = redis.createClient({
  url: process.env.REDIS_URL || 'redis://localhost:6379'
});

// PostgreSQL client
const pgPool = new Pool({
  connectionString: process.env.DATABASE_URL
});

// Initialize connections
const initializeDatabase = async () => {
  try {
    await redisClient.connect();
    console.log('Redis connected successfully');
    
    await pgPool.query('SELECT NOW()');
    console.log('PostgreSQL connected successfully');
  } catch (error) {
    console.error('Database connection failed:', error);
    process.exit(1);
  }
};

redisClient.on('error', (err) => {
  console.error('Redis Client Error', err);
});

pgPool.on('error', (err) => {
  console.error('PostgreSQL Pool Error', err);
});

module.exports = { redisClient, pgPool, initializeDatabase };
