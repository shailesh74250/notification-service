require('dotenv').config();
const emailQueue = require('../queues/emailQueue');
const EmailServiceFactory = require('../services/email/emailServiceFactory');
const logger = require('../utils/logger');
const { initializeDatabase } = require('../config/database');

logger.info('Email worker started');
initializeDatabase();

// Create email service based on environment configuration
const emailService = EmailServiceFactory.createEmailService();

// Validate email service connection on startup
emailService.validateConnection()
  .then(() => logger.info(`Email service (${process.env.EMAIL_PROVIDER || 'nodemailer'}) connected successfully`))
  .catch(err => logger.error('Email service connection failed:', err));

// Process single emails
emailQueue.process('send-email', 10, async (job) => {
  const { to, subject, html, text } = job.data;
  logger.info(`[WORKER] Processing email job ${job.id} for ${to}`);
  
  try {
    const result = await emailService.sendEmail({ to, subject, html, text });
    logger.info(`[WORKER] ✅ Email sent successfully to ${to} (Job ${job.id})`);
    return { success: true, recipient: to, result };
  } catch (error) {
    logger.error(`[WORKER] ❌ Failed to send email to ${to} (Job ${job.id})`, { error: error.message });
    throw error;
  }
});

// Process bulk emails
emailQueue.process('send-bulk-emails', 5, async (job) => {
  const { emails } = job.data;
  logger.info(`[WORKER] Processing bulk email job ${job.id} - ${emails.length} recipients`);
  
  try {
    const results = await emailService.sendBulkEmails(emails);
    logger.info(`[WORKER] ✅ Bulk email job ${job.id} completed - ${results.length} emails processed`);
    return { totalProcessed: results.length, results };
  } catch (error) {
    logger.error(`[WORKER] ❌ Bulk email job ${job.id} failed`, { error: error.message });
    throw error;
  }
});

// Graceful shutdown
process.on('SIGTERM', async () => {
  logger.info('Email worker shutting down...');
  await emailQueue.close();
  process.exit(0);
});

process.on('SIGINT', async () => {
  logger.info('Email worker shutting down...');
  await emailQueue.close();
  process.exit(0);
});
