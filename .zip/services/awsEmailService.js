const IEmailService = require('../../interfaces/IEmailService');
const AWS = require('aws-sdk');

class AWSEmailService extends IEmailService {
  constructor() {
    super();
    this.ses = new AWS.SES({
      region: process.env.AWS_REGION
    });
  }

  async sendEmail({ to, subject, html, text }) {
    const params = {
      Source: process.env.EMAIL_FROM,
      Destination: { ToAddresses: [to] },
      Message: {
        Subject: { Data: subject },
        Body: {
          Text: { Data: text },
          Html: { Data: html }
        }
      }
    };
    
    return await this.ses.sendEmail(params).promise();
  }

  async sendBulkEmails(emails) {
    // Implement AWS SES bulk sending
    const results = [];
    for (const email of emails) {
      const result = await this.sendEmail(email);
      results.push(result);
    }
    return results;
  }

  async validateConnection() {
    return await this.ses.getSendQuota().promise();
  }
}

module.exports = AWSEmailService;