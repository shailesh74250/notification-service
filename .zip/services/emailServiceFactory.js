const SendGridEmailService = require('./sendGridEmailService');
const NodemailerEmailService = require('./emailService');
const AWSEmailService = require('./awsEmailService');

class EmailServiceFactory {
  static createEmailService(provider = process.env.EMAIL_PROVIDER || 'nodemailer') {
    switch (provider.toLowerCase()) {
      case 'sendgrid':
        return new SendGridEmailService(process.env.SENDGRID_API_KEY);
      
      case 'aws':
      case 'ses':
        return new AWSEmailService();
      
      case 'nodemailer':
      case 'smtp':
        return new NodemailerEmailService({
          service: process.env.EMAIL_SERVICE || 'gmail',
          auth: {
            user: process.env.EMAIL_USER,
            pass: process.env.EMAIL_PASSWORD
          }
        });
      
      default:
        throw new Error(`Unsupported email provider: ${provider}`);
    }
  }
}

module.exports = EmailServiceFactory;