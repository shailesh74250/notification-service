const nodemailer = require('nodemailer');
const logger = require('../utils/logger');

class EmailService {
  constructor() {
    this.transporter = nodemailer.createTransport({
      host: process.env.SMTP_HOST,
      port: process.env.SMTP_PORT,
      secure: false,
      auth: {
        user: process.env.SMTP_USER,
        pass: process.env.SMTP_PASS
      },
      pool: true,
      maxConnections: 5,
      maxMessages: 100
    });
  }

  async sendEmail({ to, subject, html, text }) {
    try {
      const result = await this.transporter.sendMail({
        from: process.env.SMTP_USER,
        to,
        subject,
        html,
        text
      });
      
      logger.info(`Email sent successfully to ${to}`, { messageId: result.messageId });
      return { success: true, messageId: result.messageId };
    } catch (error) {
      logger.error(`Failed to send email to ${to}`, { error: error.message });
      throw error;
    }
  }

  async sendBulkEmails(emails) {
    const results = [];
    for (const email of emails) {
      try {
        const result = await this.sendEmail(email);
        results.push({ ...email, result });
      } catch (error) {
        results.push({ ...email, error: error.message });
      }
    }
    return results;
  }
}

module.exports = new EmailService();
