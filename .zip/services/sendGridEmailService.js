const IEmailService = require('../../interfaces/IEmailService');

class SendGridEmailService extends IEmailService {
  constructor(apiKey) {
    super();
    this.apiKey = apiKey;
    this.client = require('@sendgrid/mail');
    this.client.setApiKey(apiKey);
  }

  async sendEmail({ to, subject, html, text }) {
    const msg = {
      to,
      from: process.env.EMAIL_FROM,
      subject,
      text,
      html
    };
    
    return await this.client.send(msg);
  }

  async sendBulkEmails(emails) {
    const messages = emails.map(email => ({
      to: email.to,
      from: process.env.EMAIL_FROM,
      subject: email.subject,
      text: email.text,
      html: email.html
    }));
    
    return await this.client.send(messages);
  }

  async validateConnection() {
    // SendGrid connection validation
    return true;
  }
}

module.exports = SendGridEmailService;