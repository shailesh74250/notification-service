class IEmailService {
  async sendEmail(emailData) {
    throw new Error('sendEmail method must be implemented');
  }

  async sendBulkEmails(emailsData) {
    throw new Error('sendBulkEmails method must be implemented');
  }

  async validateConnection() {
    throw new Error('validateConnection method must be implemented');
  }
}

module.exports = IEmailService;