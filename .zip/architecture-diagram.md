# Scalable Notification Service - Architecture Diagram

## System Architecture Overview

```
┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐
│     Client      │    │   Load Balancer │    │   API Gateway   │
│   (Frontend)    │◄──►│    (Nginx)      │◄──►│   (Optional)    │
└─────────────────┘    └─────────────────┘    └─────────────────┘
                                                        │
                                                        ▼
┌─────────────────────────────────────────────────────────────────┐
│                   Express.js Application                        │
│  ┌─────────────┐ ┌─────────────┐ ┌─────────────┐ ┌─────────────┐│
│  │Rate Limiter │ │Validation   │ │Auth         │ │Logging      ││
│  │Middleware   │ │Middleware   │ │Middleware   │ │Middleware   ││
│  └─────────────┘ └─────────────┘ └─────────────┘ └─────────────┘│
└─────────────────────────────────────────────────────────────────┘
                                │
                                ▼
┌─────────────────────────────────────────────────────────────────┐
│                     Queue System (Bull/Redis)                   │
│  ┌─────────────┐ ┌─────────────┐ ┌─────────────┐ ┌─────────────┐│
│  │Email Queue  │ │SMS Queue    │ │Push Queue   │ │Retry Queue  ││
│  │             │ │             │ │             │ │             ││
│  └─────────────┘ └─────────────┘ └─────────────┘ └─────────────┘│
└─────────────────────────────────────────────────────────────────┘
                                │
                                ▼
┌─────────────────────────────────────────────────────────────────┐
│                        Worker Processes                         │
│  ┌─────────────┐ ┌─────────────┐ ┌─────────────┐ ┌─────────────┐│
│  │Email Worker │ │SMS Worker   │ │Push Worker  │ │Bulk Worker  ││
│  │             │ │             │ │             │ │             ││
│  └─────────────┘ └─────────────┘ └─────────────┘ └─────────────┘│
└─────────────────────────────────────────────────────────────────┘
                                │
                                ▼
┌─────────────────────────────────────────────────────────────────┐
│                    External Services                            │
│  ┌─────────────┐ ┌─────────────┐ ┌─────────────┐ ┌─────────────┐│
│  │SendGrid     │ │Twilio       │ │Firebase     │ │SMTP Server  ││
│  │(Email)      │ │(SMS)        │ │(Push)       │ │(Email)      ││
│  └─────────────┘ └─────────────┘ └─────────────┘ └─────────────┘│
└─────────────────────────────────────────────────────────────────┘
                                │
                                ▼
┌─────────────────────────────────────────────────────────────────┐
│                      Database Layer                             │
│  ┌─────────────┐ ┌─────────────┐ ┌─────────────┐ ┌─────────────┐│
│  │PostgreSQL   │ │Redis Cache  │ │MongoDB      │ │InfluxDB     ││
│  │(Primary)    │ │(Sessions)   │ │(Logs)       │ │(Metrics)    ││
│  └─────────────┘ └─────────────┘ └─────────────┘ └─────────────┘│
└─────────────────────────────────────────────────────────────────┘
```

## Request-Response Cycle Flow

### 1. Single Notification Request Flow

```
Client Request
     │
     ▼
┌─────────────────────────────────────────────────────────────────┐
│ POST /api/notifications                                         │
│ {                                                               │
│   "to": "user@example.com",                                     │
│   "subject": "Welcome!",                                        │
│   "html": "<h1>Welcome to our service</h1>"                    │
│ }                                                               │
└─────────────────────────────────────────────────────────────────┘
     │
     ▼
┌─────────────────────────────────────────────────────────────────┐
│ 1. Rate Limiting Check                                          │
│    - Check IP against rate limit (100 req/15min)               │
│    - Reject if exceeded                                         │
└─────────────────────────────────────────────────────────────────┘
     │
     ▼
┌─────────────────────────────────────────────────────────────────┐
│ 2. Request Validation                                           │
│    - Joi schema validation                                      │
│    - Email format validation                                    │
│    - Required fields check                                      │
└─────────────────────────────────────────────────────────────────┘
     │
     ▼
┌─────────────────────────────────────────────────────────────────┐
│ 3. Queue Job Creation                                           │
│    - Add job to Redis queue                                     │
│    - Set priority and delay                                     │
│    - Generate unique job ID                                     │
└─────────────────────────────────────────────────────────────────┘
     │
     ▼
┌─────────────────────────────────────────────────────────────────┐
│ 4. Immediate Response                                           │
│ {                                                               │
│   "id": "job_12345",                                            │
│   "status": "queued",                                           │
│   "recipient": "user@example.com",                              │
│   "createdAt": "2024-01-15T10:30:00Z"                          │
│ }                                                               │
└─────────────────────────────────────────────────────────────────┘
```

### 2. Background Processing Flow

```
Queue Job Processing
     │
     ▼
┌─────────────────────────────────────────────────────────────────┐
│ 1. Worker Process Picks Up Job                                 │
│    - Bull queue worker polls for jobs                          │
│    - FIFO processing with priority                              │
│    - Job status: queued → active                               │
└─────────────────────────────────────────────────────────────────┘
     │
     ▼
┌─────────────────────────────────────────────────────────────────┐
│ 2. Database Record Creation                                     │
│    - Insert notification record                                 │
│    - Store job metadata                                         │
│    - Log initial status                                         │
└─────────────────────────────────────────────────────────────────┘
     │
     ▼
┌─────────────────────────────────────────────────────────────────┐
│ 3. External Service Call                                        │
│    - Call SendGrid/SMTP API                                     │
│    - Handle API response                                        │
│    - Update job progress                                        │
└─────────────────────────────────────────────────────────────────┘
     │
     ▼
┌─────────────────────────────────────────────────────────────────┐
│ 4. Result Processing                                            │
│    Success:                    │    Failure:                    │
│    - Update status: completed  │    - Update status: failed     │
│    - Log success              │    - Log error details         │
│    - Remove from queue        │    - Schedule retry            │
└─────────────────────────────────────────────────────────────────┘
```

### 3. Bulk Notification Request Flow

```
Bulk Request
     │
     ▼
┌─────────────────────────────────────────────────────────────────┐
│ POST /api/notifications/bulk                                    │
│ {                                                               │
│   "emails": [                                                   │
│     {"to": "user1@example.com", "subject": "Hello 1"},         │
│     {"to": "user2@example.com", "subject": "Hello 2"},         │
│     ...                                                         │
│   ]                                                             │
│ }                                                               │
└─────────────────────────────────────────────────────────────────┘
     │
     ▼
┌─────────────────────────────────────────────────────────────────┐
│ 1. Bulk Validation                                              │
│    - Validate array length (max 10,000)                        │
│    - Validate each email object                                 │
│    - Check rate limits                                          │
└─────────────────────────────────────────────────────────────────┘
     │
     ▼
┌─────────────────────────────────────────────────────────────────┐
│ 2. Bulk Job Creation                                            │
│    - Create single bulk job                                     │
│    - Lower priority than single emails                          │
│    - Return bulk job ID                                         │
└─────────────────────────────────────────────────────────────────┘
     │
     ▼
┌─────────────────────────────────────────────────────────────────┐
│ 3. Background Bulk Processing                                   │
│    - Worker processes bulk job                                  │
│    - Split into individual email jobs                           │
│    - Process in batches                                         │
│    - Update progress incrementally                              │
└─────────────────────────────────────────────────────────────────┘
```

### 4. Status Monitoring Flow

```
Status Check Request
     │
     ▼
┌─────────────────────────────────────────────────────────────────┐
│ GET /api/notifications/{jobId}/status                           │
└─────────────────────────────────────────────────────────────────┘
     │
     ▼
┌─────────────────────────────────────────────────────────────────┐
│ 1. Job Lookup                                                   │
│    - Query Redis for job                                        │
│    - Get current state                                          │
│    - Retrieve progress info                                     │
└─────────────────────────────────────────────────────────────────┘
     │
     ▼
┌─────────────────────────────────────────────────────────────────┐
│ 2. Status Response                                              │
│ {                                                               │
│   "id": "job_12345",                                            │
│   "status": "completed",                                        │
│   "progress": 100,                                              │
│   "processedOn": "2024-01-15T10:30:15Z",                       │
│   "finishedOn": "2024-01-15T10:30:20Z"                         │
│ }                                                               │
└─────────────────────────────────────────────────────────────────┘
```

## Data Flow Diagram

```
┌─────────────┐
│   Client    │
└──────┬──────┘
       │ HTTP Request
       ▼
┌─────────────┐
│ Express API │
└──────┬──────┘
       │ Validation & Rate Limiting
       ▼
┌─────────────┐
│ Redis Queue │◄─────────────┐
└──────┬──────┘              │
       │ Job Processing      │ Retry Logic
       ▼                     │
┌─────────────┐              │
│   Worker    │──────────────┘
└──────┬──────┘
       │ External API Call
       ▼
┌─────────────┐
│ Email/SMS   │
│  Service    │
└──────┬──────┘
       │ Result
       ▼
┌─────────────┐
│ PostgreSQL  │
│  Database   │
└─────────────┘
```

## Error Handling & Retry Mechanism

```
Job Execution
     │
     ▼
┌─────────────────────────────────────────────────────────────────┐
│ Attempt 1                                                       │
│ ├─ Success → Complete Job                                        │
│ └─ Failure → Schedule Retry (Exponential Backoff)               │
└─────────────────────────────────────────────────────────────────┘
     │ (if failed)
     ▼
┌─────────────────────────────────────────────────────────────────┐
│ Attempt 2 (after 1 minute)                                     │
│ ├─ Success → Complete Job                                        │
│ └─ Failure → Schedule Retry                                     │
└─────────────────────────────────────────────────────────────────┘
     │ (if failed)
     ▼
┌─────────────────────────────────────────────────────────────────┐
│ Attempt 3 (after 5 minutes)                                    │
│ ├─ Success → Complete Job                                        │
│ └─ Failure → Move to Failed Queue                              │
└─────────────────────────────────────────────────────────────────┘
```

## Performance Considerations

- **Horizontal Scaling**: Multiple worker instances can process jobs concurrently
- **Queue Prioritization**: Critical notifications get higher priority
- **Rate Limiting**: Prevents system overload
- **Connection Pooling**: Efficient database connections
- **Caching**: Redis for session and temporary data storage
- **Monitoring**: Real-time queue statistics and job tracking
