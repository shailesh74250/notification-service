require('dotenv').config();
const express = require('express');
const rateLimit = require('express-rate-limit');
const Joi = require('joi');
const emailQueue = require('./queues/emailQueue');
const logger = require('./utils/logger');
const { pgPool } = require('./config/database');

const app = express();
const PORT = process.env.PORT || 3000;

// Rate limiting
const limiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 100, // limit each IP to 100 requests per windowMs
  message: 'Too many requests from this IP'
});

// Middleware
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true }));
app.use('/api', limiter);

// Validation schemas
const emailSchema = Joi.object({
  to: Joi.string().email().required(),
  subject: Joi.string().required(),
  html: Joi.string(),
  text: Joi.string()
}).or('html', 'text');

const bulkEmailSchema = Joi.object({
  emails: Joi.array().items(emailSchema).min(1).max(10000).required()
});

// Dummy routes
app.get('/', (req, res) => {
  res.json({ message: 'Scalable Notification Service API' });
});

// Get all notifications
app.get('/api/notifications', (req, res) => {
  res.json({
    notifications: [
      { id: 1, message: 'Welcome notification', type: 'email', status: 'sent' },
      { id: 2, message: 'Password reset', type: 'sms', status: 'pending' },
      { id: 3, message: 'Order confirmation', type: 'push', status: 'delivered' }
    ]
  });
});

// Send a single notification
app.post('/api/notifications', async (req, res) => {
  try {
    const { error, value } = emailSchema.validate(req.body);
    if (error) {
      return res.status(400).json({ error: error.details[0].message });
    }

     // Save notification to database
    await pgPool.query(
      'INSERT INTO notifications (user_id, message, type) VALUES ($1, $2, $3) RETURNING *',
      [req.body.userId, req.body.message, req.body.type]
    );

    const job = await emailQueue.add('send-email', value, {
      priority: 10,
      delay: 0
    });

    logger.info(`Email job queued`, { jobId: job.id, recipient: value.to });

    res.json({
      id: job.id,
      status: 'queued',
      recipient: value.to,
      createdAt: new Date().toISOString()
    });
  } catch (error) {
    logger.error('Failed to queue email', { error: error.message });
    res.status(500).json({ error: 'Failed to queue notification' });
  }
});

// Send bulk notifications
app.post('/api/notifications/bulk', async (req, res) => {
  try {
    const { error, value } = bulkEmailSchema.validate(req.body);
    if (error) {
      return res.status(400).json({ error: error.details[0].message });
    }

    const job = await emailQueue.add('send-bulk-emails', value, {
      priority: 5,
      delay: 0
    });

    logger.info(`Bulk email job queued`, { jobId: job.id, count: value.emails.length });

    res.json({
      id: job.id,
      status: 'queued',
      emailCount: value.emails.length,
      createdAt: new Date().toISOString()
    });
  } catch (error) {
    logger.error('Failed to queue bulk emails', { error: error.message });
    res.status(500).json({ error: 'Failed to queue bulk notifications' });
  }
});

// Get job status
app.get('/api/notifications/:id/status', async (req, res) => {
  try {
    const job = await emailQueue.getJob(req.params.id);
    if (!job) {
      return res.status(404).json({ error: 'Job not found' });
    }

    const state = await job.getState();
    res.json({
      id: job.id,
      status: state,
      progress: job.progress(),
      processedOn: job.processedOn,
      finishedOn: job.finishedOn,
      failedReason: job.failedReason
    });
  } catch (error) {
    logger.error('Failed to get job status', { error: error.message });
    res.status(500).json({ error: 'Failed to get job status' });
  }
});

// Queue statistics
app.get('/api/queue/stats', async (req, res) => {
  try {
    const waiting = await emailQueue.getWaiting();
    const active = await emailQueue.getActive();
    const completed = await emailQueue.getCompleted();
    const failed = await emailQueue.getFailed();

    res.json({
      waiting: waiting.length,
      active: active.length,
      completed: completed.length,
      failed: failed.length
    });
  } catch (error) {
    logger.error('Failed to get queue stats', { error: error.message });
    res.status(500).json({ error: 'Failed to get queue statistics' });
  }
});

// Health check
app.get('/health', (req, res) => {
  res.json({ status: 'OK', timestamp: new Date().toISOString() });
});

// Add worker health check
app.get('/health/workers', async (req, res) => {
  try {
    const waiting = await emailQueue.getWaiting();
    const active = await emailQueue.getActive();
    const failed = await emailQueue.getFailed();
    
    res.json({
      status: 'OK',
      workers: {
        waiting: waiting.length,
        active: active.length,
        failed: failed.length,
        healthy: active.length > 0 || waiting.length === 0
      }
    });
  } catch (error) {
    res.status(500).json({ status: 'ERROR', error: error.message });
  }
});

// Test endpoint to trigger email jobs
app.post('/api/test/email', async (req, res) => {
  try {
    const job = await emailQueue.add('send-email', {
      to: 'test@example.com',
      subject: 'Test Email from Worker',
      text: 'This is a test email to verify the worker is processing jobs.',
      html: '<p>This is a <strong>test email</strong> to verify the worker is processing jobs.</p>'
    });

    logger.info(`[API] Test email job created with ID: ${job.id}`);
    
    res.json({
      message: 'Test email job queued successfully',
      jobId: job.id,
      checkStatus: `/api/notifications/${job.id}/status`
    });
  } catch (error) {
    logger.error('[API] Failed to queue test email', { error: error.message });
    res.status(500).json({ error: 'Failed to queue test email' });
  }
});

// Test bulk email endpoint
app.post('/api/test/bulk-email', async (req, res) => {
  try {
    const testEmails = [
      { to: 'test1@example.com', subject: 'Bulk Test 1', text: 'Test email 1' },
      { to: 'test2@example.com', subject: 'Bulk Test 2', text: 'Test email 2' },
      { to: 'test3@example.com', subject: 'Bulk Test 3', text: 'Test email 3' }
    ];

    const job = await emailQueue.add('send-bulk-emails', {
      emails: testEmails
    });

    logger.info(`[API] Test bulk email job created with ID: ${job.id}`);
    
    res.json({
      message: 'Test bulk email job queued successfully',
      jobId: job.id,
      emailCount: testEmails.length,
      checkStatus: `/api/notifications/${job.id}/status`
    });
  } catch (error) {
    logger.error('[API] Failed to queue test bulk email', { error: error.message });
    res.status(500).json({ error: 'Failed to queue test bulk email' });
  }
});

// Start server
app.listen(PORT, () => {
  console.log(`Notification service running on port ${PORT}`);
  logger.info(`Notification service started on port ${PORT}`);
});

module.exports = app;
